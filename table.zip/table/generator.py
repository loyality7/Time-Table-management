import pandas as pd
import random

def generate_timetable(year, group, section):
    # Your existing code to generate the timetable remains the same.
    timetable = generate_timetable_logic(year, group, section)
    return timetable

# Add a new function to generate timetable without user prompts
def generate_timetable_logic(year, group, section):
    # Load subjects data from the CSV file
    subjects_df = pd.read_csv('data/subjects.csv')

    # Load lecturers data from the CSV file
    lecturers_df = pd.read_csv(f'data/year{year}_group{group}_lecturers.csv')

    # Create a timetable dictionary to store the schedule
    timetable = {}
    
    # Iterate through each subject
    for _, subject_row in subjects_df.iterrows():
        subject = subject_row['name']
        daily_hours = subject_row['daily_hours']

        # Initialize a list of lecturers for the subject
        subject_lecturers = []

        # Find lecturers available for this subject
        for _, lecturer_row in lecturers_df.iterrows():
            lecturer_name = lecturer_row['name']
            available_hours = lecturer_row['available_hours']
            classes_per_day = lecturer_row['classes_per_day']

            # Check if the lecturer is available and not exceeding their daily classes limit
            if available_hours >= daily_hours and classes_per_day < 2:
                subject_lecturers.append(lecturer_name)

        # If there are no available lecturers for this subject, raise an error
        if not subject_lecturers:
            raise Exception(f"No available lecturers for {subject} in Year {year}, Group {group}")

        # Randomly select a lecturer for the subject
        selected_lecturer = random.choice(subject_lecturers)

        # Update lecturer's available hours and classes per day
        lecturer_index = lecturers_df.index[lecturers_df['name'] == selected_lecturer][0]
        lecturers_df.at[lecturer_index, 'available_hours'] -= daily_hours
        lecturers_df.at[lecturer_index, 'classes_per_day'] += 1

        # Add the subject and lecturer to the timetable
        timetable[subject] = selected_lecturer

    return timetable
