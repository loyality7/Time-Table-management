import pandas as pd

def create_lecturers_csv(year, groups):
    num_lecturers = 80  # Total number of lecturers
    num_subjects = 6   # Number of subjects

    lecturers = [f'Lect{i}' for i in range(1, num_lecturers + 1)]
    lecturer_subjects = [", ".join([f'sub{j}' for j in range(1, num_subjects + 1)]) for _ in range(num_lecturers)]
    available_hours = [6] * num_lecturers
    classes_per_day = [0] * num_lecturers

    data = {
        'name': lecturers,
        'available_hours': available_hours,
        'classes_per_day': classes_per_day,
        'subjects': lecturer_subjects
    }

    lecturers_df = pd.DataFrame(data)

    # Save the CSV file for each group
    for group in range(1, groups + 1):
        lecturers_df.to_csv(f'data/year{year}_group{group}_lecturers.csv', index=False)

if __name__ == '__main__':
    year = 2
    groups = 8
    create_lecturers_csv(year, groups)
