import pandas as pd

# List of subjects and their daily class hours
data = {
    'name': ['sub1', 'sub2', 'sub3', 'sub4', 'sub5', 'sub6'],
    'daily_hours': [4, 4, 4, 4, 4, 4]
}

# Create a DataFrame
subjects_df = pd.DataFrame(data)

# Save the DataFrame to a CSV file
subjects_df.to_csv('data/subjects.csv', index=False)
