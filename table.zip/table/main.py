import tkinter as tk
from tkinter import ttk
import generator

# Function to generate a timetable and display it
def generate_timetable():
    year = int(year_var.get())
    group = int(group_var.get())
    section = section_var.get()

    timetable = generator.generate_timetable(year, group, section)

    # Display the timetable
    result_text.delete(1.0, tk.END)  # Clear previous results
    result_text.insert(tk.END, f"Timetable for Year {year}, Group {group}, Section {section}:\n\n")
    for subject, lecturer in timetable.items():
        result_text.insert(tk.END, f"Subject: {subject}\n")
        result_text.insert(tk.END, f"Lecturer: {lecturer}\n\n")

# Create a Tkinter window
window = tk.Tk()
window.title("Timetable Generator")

# Year selection
year_label = ttk.Label(window, text="Choose a year:")
year_label.grid(row=0, column=0, padx=10, pady=5)
year_var = tk.StringVar()
year_combo = ttk.Combobox(window, textvariable=year_var, values=["1", "2", "3"])
year_combo.grid(row=0, column=1, padx=10, pady=5)
year_combo.set("1")

# Group selection
group_label = ttk.Label(window, text="Enter the group number (1 to 8):")
group_label.grid(row=1, column=0, padx=10, pady=5)
group_var = tk.StringVar()
group_entry = ttk.Entry(window, textvariable=group_var)
group_entry.grid(row=1, column=1, padx=10, pady=5)

# Section selection
section_label = ttk.Label(window, text="Enter the section (A or B):")
section_label.grid(row=2, column=0, padx=10, pady=5)
section_var = tk.StringVar()
section_entry = ttk.Entry(window, textvariable=section_var)
section_entry.grid(row=2, column=1, padx=10, pady=5)

# Generate button
generate_button = ttk.Button(window, text="Generate Timetable", command=generate_timetable)
generate_button.grid(row=3, column=0, columnspan=2, pady=10)

# Result text box
result_text = tk.Text(window, height=10, width=40)
result_text.grid(row=4, column=0, columnspan=2, padx=10, pady=10)

# Start the Tkinter main loop
window.mainloop()
